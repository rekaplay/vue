export enum ScopeType {
	'view',
	'update',
	'create',
}
