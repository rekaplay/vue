export interface ILabels {
    Nombre: string;
    Apellido: string;
}