export interface IDataTable {
	[key: string]: any;
}
